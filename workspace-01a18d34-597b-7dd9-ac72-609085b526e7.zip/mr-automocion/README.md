# MR Automoción — prototipo web

Web responsive para comprar, explorar y gestionar anuncios de coches. Incluye catálogo con filtros, fichas de vehículo, favoritos, contacto por Instagram y panel del propietario para subir fotos, publicar, editar, marcar como vendido y eliminar vehículos.

## Ejecutar

```bash
npm install
npm run dev
```

## Importante antes de publicar

Este es un **prototipo funcional local**: los anuncios añadidos se guardan en `localStorage` del navegador, no en un servidor. El panel no tiene autenticación y los datos no se comparten entre dispositivos. **No se debe publicar como plataforma multiusuario o tienda real en este estado.** Para producción hace falta base de datos y almacenamiento de imágenes, inicio de sesión seguro para el propietario, políticas de privacidad/aviso legal/cookies según corresponda, y datos reales de contacto y stock. Los cuatro coches iniciales están marcados como ejemplos y pueden quitarse desde el panel. No se han copiado contenidos de Instagram porque el perfil no era accesible automáticamente.

## Personalización

- Perfil de contacto: constante `IG` en `src/main.jsx`.
- Nombre y contenido: `src/main.jsx`.
- Colores y tipografía: `src/style.css`.
- Imagen de portada: `public/hero-car.jpg`.

## Despliegue

La versión de demostración está publicada en https://mr-automocion.vercel.app/ (proyecto `olaolek220/mr-automocion`). El panel sigue guardando datos solo en el navegador; el despliegue por sí solo no crea una base de datos ni autenticación.
